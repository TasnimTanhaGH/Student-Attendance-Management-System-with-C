Admin ID: 12345678
Password: 6598

Teacher ID: 12345678
Password: 6598
